<template>
  <div>
    <!-- <div v-show="dialogVisible"> -->
    <el-dialog
      title="新增用户"
      :visible.sync="dialogVisible"
      width="30%"
      :before-close="handleClose"
    >
      <list ref="list" @submit-success="handleSubmitSuccess"></list>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleAdd">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="修改信息"
      :visible.sync="dialogVisible1"
      width="30%"
      :before-close="handleClose"
    >
      <change ref="change" :rowData="clickedRowData"  @submit-success="handleSubmitSuccess"></change>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible1 = false">取 消</el-button>
        <el-button type="primary" @click="handleAdd1">确 定</el-button>
      </span>
    </el-dialog>
    <!-- </div> -->

    <div>
      关键字
      <el-input v-model="input" class="sousuo" placeholder="客户姓名/电话"></el-input>
      <el-button icon="el-icon-search" type="primary" @click="search">搜索</el-button
      ><br />
      <el-button type="primary" icon=" el-icon-plus" plain @click="dialogVisible = true"
        >新增</el-button
      >
    </div>
    <el-table
      ref="multipleTable"
      :data="tableData1"
      tooltip-effect="dark"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column label="姓名" width="120">
        <template slot-scope="{ row }">{{ row.name }}</template>
      </el-table-column>
      <el-table-column label="电话" align="center" width="120">
        <!-- 解构 -->
        <template slot-scope="{ row }">{{ row.phone }}</template>
      </el-table-column>
      <el-table-column label="性别" align="center" width="120">
        <!-- 解构 -->
        <template slot-scope="{ row }">{{ row.sex }}</template>
      </el-table-column>
      <el-table-column prop="address" label="地址" show-overflow-tooltip>
      </el-table-column>
      <el-table-column label="操作" align="center" width="120">
        <!-- 解构 -->
        <template slot-scope="{ row }">
          <div class="container">
            <el-button
              type="danger"
              icon="el-icon-delete"
              circle
              @click="deletelist(row.id)"
            ></el-button>

            <i class="el-icon-edit"></i><span @click="xiugai(row)">修改</span>
          </div>
        </template>
      </el-table-column>
    </el-table>

    <div style="display: flex; justify-content: flex-end; padding: 20px 20px 0 0">
      <el-pagination
    
        @size-change="sizeChange"
        @current-change="currentChange"
        :current-page="currentPage4"
        :page-sizes="[10, 20, 30, 40]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total= this.tableData.length
      >
      </el-pagination>
    </div>
  </div>
</template>
<script>
import axios from "axios";

import list from "./add/list.vue";
import change from "./change";
export default {
  data() {
    return {
      page: 1, //第几页
      size: 10, //一页多少条
      total: 0, //总条目数
      pageSizes: [3, 5, 10, 20, 50, 100, 200, 300, 400, 500, 1000], //可选择的一页多少条
      tableData1: [], //表格绑定的数据
      tableData: [],
      input: "",
      dialogVisible: false,
      dialogVisible1: false,
      id: "",
    };
  },
  components: {
    list,
    change,
  },
  created() {
    this.fetchPersons();
   
  },
  methods: {
    getTabelData() {
        //allData为全部数据
      this.tableData1 = this.tableData.slice(
        (this.page - 1) * this.size,
        this.page * this.size
      );
      console.log("127",this.tableData1);
      this.total=this.tableData.length
    },
    getTabelData2() {
      let data=JSON.parse(JSON.stringify(this.tableData))
      this.tableData1 = data.splice(
        (this.page - 1) * this.size,
        this.size
      );
      console.log("127",this.tableData1);
      this.total=this.tableData.length
    },
    currentChange(val) {
      console.log("翻页，当前为第几页", val);
      this.page = val;
      this.getTabelData2();
    },
    //size改变时回调的函数，参数为当前的size
    sizeChange(val) {
      console.log("改变每页多少条，当前一页多少条数据", val);
      this.size = val;
      this.page = 1; 
      this.getTabelData2();
    },
    handleSubmitSuccess() {
      this.fetchPersons();
    },
    xiugai(row) {
      this.clickedRowData = row;
      console.log(row);
      // this.$refs.list.submitForm();
      this.dialogVisible1 = true;
    },
    deletelist(id) {
      axios
        .delete(`http://localhost:3000/List/${id}`)
        .then((response) => {
          this.fetchPersons();
          console.log("数据删除成功：", response.data);
        })
        .catch((error) => {
          console.error("数据删除失败：", error);
        });
    },
    handleAdd() {
      console.log(111);
      this.$refs.list.submitForm();
      this.$refs.list.clearFields();
      this.dialogVisible = false;
    },
    handleAdd1() {
      console.log(33333);
      this.$refs.change.submitForm();
      // this.$refs.change.clearFields(); // 调用子组件的清空输入框方法
      
      this.dialogVisible1 = false;
    },
    add() {
      this.dialogVisible = true;
    },
    handleClose(done) {
      this.$confirm("确认关闭？")
        .then((_) => {
          done();
        })
        .catch((_) => {});
    },
    search() {
      axios
        .get("http://localhost:3000/List") // 发起 GET 请求到模拟的 JSON Server
        .then((response) => {
          console.log("response", response);
          this.tableData1 = response.data.filter((item) => {
            return (
              item.name.includes(this.input) ||
              item.phone.includes(this.input) ||
              item.address.includes(this.input) ||
              item.sex.includes(this.input)
            );
          });
        })
        .catch((error) => {
          console.error("搜索请求失败:", error);
        });
    },
    fetchPersons() {
      axios
        .get("http://localhost:3000/List") // 发起 GET 请求到模拟的 JSON Server
        .then((response) => {
          this.tableData = response.data;
           this.getTabelData2();
          this.id = this.tableData.map((item) => item.id);
          console.log("id", this.id);
          console.log("发送成功", response.data);
        })
        .catch((error) => {});
    },
    setCurrent(row) {
      // this.$refs.singleTable.setCurrentRow(row);
    },
    handleCurrentChange(val) {
      // this.currentRow = val;
    },
    handleSelectionChange() {},
    // handleSizeChange(val) {
    //   console.log(`每页 ${val} 条`);
    // },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
  },
};
</script>
<style scoped>
.sousuo {
  width: 300px;
}
.button-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 50px; /* 设置两个元素之间的间距 */
}
</style>

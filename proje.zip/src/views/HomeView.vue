<template>
  <div>
    <h1>人员管理系统</h1>
    <div v-if="loading">加载中...</div>
    <div v-else>
      <h2>人员列表</h2>
      <ul>
        <li v-for="person in persons" :key="person.id">
          {{ person.name }} - {{ person.age }}
          <button @click="editPerson(person)">编辑</button>
          <button @click="deletePerson(person.id)">删除</button>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      persons: [],
      loading: true
    };
  },
  mounted() {
    this.fetchPersons();
  },
  methods: {
    fetchPersons() {
      axios.get('http://localhost:3000/bannerList') // 发起 GET 请求到模拟的 JSON Server
        .then(response => {

          console.log("发送成功",response.data);
          // this.persons = response.data;
          // this.loading = false;
        })
        .catch(error => {
          console.error('获取数据出错：', error);
          this.loading = false;
        });
    },
    editPerson(person) {
      // 编辑逻辑
      console.log('编辑人员信息：', person);
    },
    deletePerson(id) {
      axios.delete(`http://localhost:3000/persons/${id}`) // 发起 DELETE 请求到模拟的 JSON Server
        .then(response => {
          console.log('删除人员信息：', response.data);
          this.fetchPersons(); // 删除后重新获取人员列表数据
        })
        .catch(error => {
          console.error('删除人员出错：', error);
        });
    }
    // 其他方法，如添加人员等...
  }
};
</script>

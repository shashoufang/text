<template>
    <div>
      <el-form :model="formData" ref="form" label-width="80px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="formData.name" placeholder="请输入姓名"></el-input>
        </el-form-item>
        <el-form-item label="电话" prop="phone">
          <el-input v-model="formData.phone" placeholder="请输入电话"></el-input>
        </el-form-item>
        <el-form-item label="性别" prop="sex">
          <el-radio-group v-model="formData.sex">
            <el-radio label="male">男性</el-radio>
            <el-radio label="female">女性</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="地址" prop="address">
          <el-input v-model="formData.address" placeholder="请输入地址"></el-input>
        </el-form-item>
      </el-form>
    </div>
  </template>
  
  <script>
    import axios from "axios"
  export default {
    data() {
      return {
        formData: {
          name: '',
          phone: '',
          sex: '',
          address: ''
        }
      };
    },
    methods: {
      clearFields() {
      // 清空输入框的逻辑
      this.formData.name = ''; // 假设清空姓名字段
      this.formData.phone = ''; // 假设清空电话字段
      this.formData.sex = ''; // 假设清空性别字段
      this.formData.address = ''; // 假设清空地址字段
    },
      submitForm() {
        this.$refs.form.validate(valid => {
          if (valid) {  
            if (this.formData.sex === 'male') {
          this.formData.sex = '男';
        } else {
          this.formData.sex = '女';
        }
            // 表单验证通过，可以在这里提交数据，或执行其他操作
            axios.post('http://localhost:3000/List', this.formData)
            .then((response) => {
              // 在控制台打印成功信息，可以根据实际情况进行处理
              console.log('提交成功', response.data);

              // 刷新页面（注意：以下代码将重新加载整个页面，请谨慎使用）
              this.$emit('submit-success');
            })
            .catch((error) => {
              // 提交失败，输出错误信息
              console.error('提交失败', error);
            });
            console.log('表单数据:', this.formData);
          } else {
            // 表单验证失败，可以给出提示信息
            this.$message.error('表单数据验证失败');
          }
        });
      }
    }
  };
  </script>
  
  <style>
  /* 可以根据需要添加样式 */
  </style>
  